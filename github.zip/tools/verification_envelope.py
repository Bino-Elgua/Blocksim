"""
Generate a Verification Envelope (template). Operators must fill executor_pubkey and sign raw_response.
This script does NOT generate private keys or signatures.
"""
import json
import time
from typing import Dict

def make_envelope(service: str, id: str, raw_response: Dict, executor_pubkey: str = "", signature: str = "") -> Dict:
    envelope = {
        "service": service,
        "id": id,
        "raw_response": raw_response,
        "utc_timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "executor_pubkey": executor_pubkey,
        "signature": signature
    }
    return envelope

if __name__ == "__main__":
    sample = make_envelope("blocksim.chain", "op_run_0001", {"status":"ok"}, executor_pubkey="", signature="")
    print(json.dumps(sample, indent=2))