from fastapi import FastAPI, APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Any, Dict
from app.chain_service import chain_service

app = FastAPI(title="BlockSim Chain API")
router = APIRouter()

class StakeRequest(BaseModel):
    wallet_id: str
    amount: float

@router.post("/stake")
async def stake_tokens(req: StakeRequest):
    ok = chain_service.economics.stake(req.wallet_id, req.amount)
    if ok:
        return {"status": "staked", "amount": req.amount}
    raise HTTPException(status_code=400, detail="stake_failed")

class DeployFirmwareRequest(BaseModel):
    device_id: str
    firmware_version: str
    firmware_hash: str  # sha256 hex
    deployer_key: str

@router.post("/deploy_firmware")
async def deploy_firmware(req: DeployFirmwareRequest):
    # Authorization enforced in firmware_deploy block as well; here we check minimal guard
    # This endpoint registers firmware metadata in the chain registry.
    try:
        chain_service.register_firmware(
            version=req.firmware_version,
            pcr=f"pcr_{req.firmware_version}",
            binary_sha256=req.firmware_hash
        )
        return {"status": "registered", "device_id": req.device_id, "firmware_hash": req.firmware_hash}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class SubmitLogRequest(BaseModel):
    device_id: str
    wallet_id: str
    sim_log: Dict[str, Any]
    firmware_version: str
    stake_amount: float = 10.0

@router.post("/submit_log")
async def submit_log(req: SubmitLogRequest):
    # Run the chain_submit logic path in a single operation:
    #  - basic stake check, device register, attestation check, submit_log, anomaly check, reward
    from app.blocks.chain_submit import chain_submit  # reuse block logic
    inputs = {"sim_log": req.sim_log}
    params = {
        "device_id": req.device_id,
        "wallet_id": req.wallet_id,
        "stake_amount": req.stake_amount,
        "firmware_version": req.firmware_version
    }
    result = chain_submit(inputs, params, dt=0.0)
    return result

app.include_router(router, prefix="/api/chain", tags=["Chain"])